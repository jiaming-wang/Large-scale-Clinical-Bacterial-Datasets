import os
import xml.etree.ElementTree as ET

def check_xml_for_objects(xml_path):
    """检查XML文件中是否存在目标"""
    tree = ET.parse(xml_path)
    root = tree.getroot()
    objects = root.findall('object')
    return len(objects) > 0

def process_xml_files(input_txt, has_object_txt, no_object_txt):
    with open(input_txt, 'r') as file:
        lines = file.readlines()

    with open(has_object_txt, 'w') as has_obj_file, open(no_object_txt, 'w') as no_obj_file:
        for line in lines:
            xml_path = line.strip()
            xml_path = os.path.join("/media/sdd/wjmecho/mmdetection/data/VOC2007/lixml/",xml_path+".xml")
            if os.path.exists(xml_path) and xml_path.endswith('.xml'):
                if check_xml_for_objects(xml_path):
                    has_obj_file.write(xml_path + '\n')
                else:
                    no_obj_file.write(xml_path + '\n')
            else:
                print(f"文件不存在或不是XML文件: {xml_path}")

# 设置输入和输出文件的路径
input_txt_path = '/media/sdd/wjmecho/mmdetection/data/VOC2007/train.txt'
has_object_txt_path = './has_object.txt'
no_object_txt_path = './no_object.txt'

# 处理XML文件
process_xml_files(input_txt_path, has_object_txt_path, no_object_txt_path)
