'''
Author: Jiaming-Wang wjmecho@163.com
Date: 2024-09-04 09:13:58
LastEditors: Jiaming-Wang wjmecho@163.com
LastEditTime: 2024-09-04 09:14:01
FilePath: /Det_tool/num_woobject.py
Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
'''
import os
import xml.etree.ElementTree as ET

def count_no_object_xml(xml_folder):
    no_object_count = 0
    no_object_files = []

    # 遍历xml文件夹中的所有文件
    for xml_file in os.listdir(xml_folder):
        if xml_file.endswith('.xml'):
            xml_path = os.path.join(xml_folder, xml_file)
            
            # 解析XML文件
            tree = ET.parse(xml_path)
            root = tree.getroot()

            # 检查是否包含<object>标签
            objects = root.findall('object')
            if not objects:
                no_object_count += 1
                no_object_files.append(xml_file)

    return no_object_count, no_object_files

# 设定XML文件所在的文件夹路径
xml_folder_path = '/media/sdd/wjmecho/mmdetection/data/VOC2007/xmlb'

# 统计并打印结果
no_object_count, no_object_files = count_no_object_xml(xml_folder_path)
print(f'没有目标的XML文件数量: {no_object_count}')
# print('没有目标的XML文件:')
# for file in no_object_files:
#     print(file)